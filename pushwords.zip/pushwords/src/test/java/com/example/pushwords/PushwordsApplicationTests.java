package com.example.pushwords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PushwordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
